module.exports = {
  'add': require('./add'),
  'ceil': require('./ceil'),
  'divide': require('./divide'),
  'floor': require('./floor'),
  'max': require('./max'),
  'maxBy': require('./maxBy'),
  'mean': require('./mean'),
  'meanBy': require('./meanBy'),
  'min': require('./min'),
  'minBy': require('./minBy'),
  'multiply': require('./multiply'),
  'round': require('./round'),
  'subtract': require('./subtract'),
  'sum': require('./sum'),
  'sumBy': require('./sumBy')
};
