import mod from "./index.js";

export default mod;
