import { MetadataJson } from './types.d.js';

declare const metadata: MetadataJson;
export default metadata;
