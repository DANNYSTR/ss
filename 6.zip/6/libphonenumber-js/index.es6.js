// This file is deprecated.
// It's only for backwards compatibility with some old code that might've imported
// the library by a full path of the old `index.es6.js` file. That file was renamed
// to `index.js`.

export * from './index.js'