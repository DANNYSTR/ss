import Image from './dist/shared/lib/image-external'
export * from './dist/shared/lib/image-external'
export default Image
