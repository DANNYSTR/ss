import App from './dist/pages/_app'
export * from './dist/pages/_app'
export default App
