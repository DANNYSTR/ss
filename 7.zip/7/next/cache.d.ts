export { unstable_cache } from 'next/dist/server/web/spec-extension/unstable-cache'
export { revalidatePath } from 'next/dist/server/web/spec-extension/revalidate-path'
export { revalidateTag } from 'next/dist/server/web/spec-extension/revalidate-tag'
export { unstable_noStore } from 'next/dist/server/web/spec-extension/unstable-no-store'
