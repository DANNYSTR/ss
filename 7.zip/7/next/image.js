module.exports = require('./dist/shared/lib/image-external')
