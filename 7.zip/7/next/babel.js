module.exports = require('./dist/build/babel/preset')
