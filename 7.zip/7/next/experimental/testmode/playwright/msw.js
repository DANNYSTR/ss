module.exports = require('../../../dist/experimental/testmode/playwright/msw')
