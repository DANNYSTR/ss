module.exports = require('./dist/shared/lib/runtime-config.external')
