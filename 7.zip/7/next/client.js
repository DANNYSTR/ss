module.exports = require('./dist/client/index')
