const axiosRetry = require('./lib/cjs/index').default;

module.exports = axiosRetry;
module.exports.default = axiosRetry;
