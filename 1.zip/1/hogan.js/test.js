var template = require('./lib/hogan.js').compile('{{a}}');
console.log(template.render({a:'C:\\werwr\\werwer'}))

    var x = require('./lib/hogan.js').compile('{{a}}').render({a:'C:\\werwr\\werwer'});

console.log(x)