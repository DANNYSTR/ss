require('./index.js')(function (e, os) {
  if (e) return console.log(e)
  return console.log(JSON.stringify(os))
})
