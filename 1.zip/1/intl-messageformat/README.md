# Intl MessageFormat

We've migrated the docs to https://formatjs.io/docs/intl-messageformat.
