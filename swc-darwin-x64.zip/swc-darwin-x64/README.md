# `@next/swc-darwin-x64`

This is the **x86_64-apple-darwin** binary for `@next/swc`
