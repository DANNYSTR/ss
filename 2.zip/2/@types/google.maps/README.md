# Installation
> `npm install --save @types/google.maps`

# Summary
This package contains type definitions for Google Maps JavaScript API (https://developers.google.com/maps/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/google.maps.

### Additional Details
 * Last updated: Fri, 15 Sep 2023 19:38:58 GMT
 * Dependencies: none
 * Global values: `google`

# Credits
These definitions were written by [Alex Muramoto](https://github.com/amuramoto), and [Angela Yu](https://github.com/wangela).
