# Installation
> `npm install --save @types/argparse`

# Summary
This package contains type definitions for argparse (https://github.com/nodeca/argparse).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/argparse.

### Additional Details
 * Last updated: Tue, 31 Dec 2019 23:55:49 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Andrew Schurman (https://github.com/arcticwaters), Tomasz Łaziuk (https://github.com/tlaziuk), Sebastian Silbermann (https://github.com/eps1lon), Kannan Goundan (https://github.com/cakoose), and Halvor Holsten Strand (https://github.com/ondkloss).
