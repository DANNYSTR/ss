import { trimStart } from "./index";
export = trimStart;
