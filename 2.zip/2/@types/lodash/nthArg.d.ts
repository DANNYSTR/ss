import { nthArg } from "./index";
export = nthArg;
