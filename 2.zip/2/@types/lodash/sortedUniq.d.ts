import { sortedUniq } from "./index";
export = sortedUniq;
