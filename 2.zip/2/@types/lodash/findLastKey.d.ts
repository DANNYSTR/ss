import { findLastKey } from "./index";
export = findLastKey;
