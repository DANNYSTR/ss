import { maxBy } from "./index";
export = maxBy;
