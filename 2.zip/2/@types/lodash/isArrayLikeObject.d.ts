import { isArrayLikeObject } from "./index";
export = isArrayLikeObject;
