import { transform } from "./index";
export = transform;
