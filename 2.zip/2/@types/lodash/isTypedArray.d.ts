import { isTypedArray } from "./index";
export = isTypedArray;
