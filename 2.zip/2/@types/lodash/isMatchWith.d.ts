import { isMatchWith } from "./index";
export = isMatchWith;
