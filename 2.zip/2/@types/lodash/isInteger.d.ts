import { isInteger } from "./index";
export = isInteger;
