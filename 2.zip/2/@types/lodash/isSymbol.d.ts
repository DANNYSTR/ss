import { isSymbol } from "./index";
export = isSymbol;
