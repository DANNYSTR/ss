import { floor } from "./index";
export = floor;
