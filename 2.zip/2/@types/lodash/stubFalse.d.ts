import { stubFalse } from "./index";
export = stubFalse;
