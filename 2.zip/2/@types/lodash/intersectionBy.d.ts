import { intersectionBy } from "./index";
export = intersectionBy;
