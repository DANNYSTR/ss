import { overEvery } from "./index";
export = overEvery;
