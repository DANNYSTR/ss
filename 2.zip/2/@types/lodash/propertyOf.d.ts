import { propertyOf } from "./index";
export = propertyOf;
