import { isObjectLike } from "./index";
export = isObjectLike;
