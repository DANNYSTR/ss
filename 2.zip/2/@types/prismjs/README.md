# Installation
> `npm install --save @types/prismjs`

# Summary
This package contains type definitions for prismjs (http://prismjs.com/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/prismjs.

### Additional Details
 * Last updated: Wed, 18 Oct 2023 18:04:04 GMT
 * Dependencies: none

# Credits
These definitions were written by [Michael Schmidt](https://github.com/RunDevelopment), [ExE Boss](https://github.com/ExE-Boss), [Erik Lieben](https://github.com/eriklieben), [Andre Wiggins](https://github.com/andrewiggins), and [Michał Miszczyszyn](https://github.com/mmiszy).
