# Installation
> `npm install --save @types/triple-beam`

# Summary
This package contains type definitions for triple-beam (https://github.com/winstonjs/triple-beam).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/triple-beam.
## [index.d.ts](https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/triple-beam/index.d.ts)
````ts
// Type definitions for triple-beam 1.3
// Project: https://github.com/winstonjs/triple-beam
// Definitions by: Daniel Byrne <https://github.com/danwbyrne>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped

export as namespace TripleBeam;

export const LEVEL: unique symbol;
export const MESSAGE: unique symbol;
export const SPLAT: unique symbol;
export const configs: Configs;

export interface Config {
    readonly levels: { [k: string]: number };
    readonly colors: { [k: string]: string };
}

export interface Configs {
    readonly cli: Config;
    readonly npm: Config;
    readonly syslog: Config;
}

````

### Additional Details
 * Last updated: Tue, 12 Sep 2023 12:34:50 GMT
 * Dependencies: none
 * Global values: `TripleBeam`

# Credits
These definitions were written by [Daniel Byrne](https://github.com/danwbyrne).
