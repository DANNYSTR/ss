# Installation
> `npm install --save @types/hogan.js`

# Summary
This package contains type definitions for hogan.js (http://twitter.github.com/hogan.js/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/hogan.js.

### Additional Details
 * Last updated: Sat, 16 Sep 2023 08:06:32 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Andrew Leedham](https://github.com/AndrewLeedham).
