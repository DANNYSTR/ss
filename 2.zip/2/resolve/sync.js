'use strict';

module.exports = require('./lib/sync');
