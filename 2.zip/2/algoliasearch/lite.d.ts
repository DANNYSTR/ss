/* eslint-disable import/no-unresolved*/
export * from './dist/algoliasearch-lite';
export { default } from './dist/algoliasearch-lite';
