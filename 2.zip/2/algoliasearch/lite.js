// eslint-disable-next-line functional/immutable-data, import/no-commonjs
module.exports = require('./index');
