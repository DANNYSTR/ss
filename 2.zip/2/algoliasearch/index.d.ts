/* eslint-disable import/no-unresolved*/
export * from './dist/algoliasearch';
export { default } from './dist/algoliasearch';
