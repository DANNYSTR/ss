import callBind from 'call-bind';

import getPolyfill from 'reflect.getprototypeof/polyfill';

export default callBind(getPolyfill(), typeof Reflect === 'object' ? Reflect : Object);

export { default as getPolyfill } from 'reflect.getprototypeof/polyfill';
export { default as implementation } from 'reflect.getprototypeof/implementation';
export { default as shim } from 'reflect.getprototypeof/shim';
