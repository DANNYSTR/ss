
0.1.1 / 2020-09-18
==================

  * Add types
  * slashes -> remove-trailing-slash
  * ignore component.json in npm

# 0.1.0

- initial release
