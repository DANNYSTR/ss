declare module 'remove-trailing-slash' {
  function removeTrailingSlash(str: string): string;
  export = removeTrailingSlash;
}
