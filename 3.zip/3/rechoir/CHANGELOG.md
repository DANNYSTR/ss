# Changelog

## [0.8.0](https://www.github.com/gulpjs/rechoir/compare/v0.7.1...v0.8.0) (2021-07-24)


### ⚠ BREAKING CHANGES

* Normalize repository, dropping node <10.13 support (#40)

### Miscellaneous Chores

* Normalize repository, dropping node <10.13 support ([#40](https://www.github.com/gulpjs/rechoir/issues/40)) ([00f5968](https://www.github.com/gulpjs/rechoir/commit/00f59689d0eb9668d939a85e06428a0906587a6f))
