# `@next/eslint-plugin-next`

Documentation for `@next/eslint-plugin-next` can be found at:
https://nextjs.org/docs/basic-features/eslint#eslint-plugin
