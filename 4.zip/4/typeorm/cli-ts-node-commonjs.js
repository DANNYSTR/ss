#!/usr/bin/env node
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("ts-node").register();
require("./cli");

//# sourceMappingURL=cli-ts-node-commonjs.js.map
