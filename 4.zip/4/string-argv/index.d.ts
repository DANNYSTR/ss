export { parseArgsStringToArgv };
export default function parseArgsStringToArgv(value: string, env?: string, file?: string): string[];
